<!DOCTYPE html>
<html>
<head>
	<title>My Future Timeline</title>
	<!-- Global Css using Helper -->
	<?php 
			globalCss(); 
	?>
	<!--/ Global Css using Helper -->
</head>
<body>
	<!-- Navbar -->
		<?php include 'navbar.php'?>
	<!--/ Navbar -->

	<div class="container-fluid categories-home">
		<div class="container">
			<legend>Categories</legend>
			<small id="fileHelp" class="form-text text-muted">Click on the Categries and select the Documents for merging.</small>
			<div class="category-container">

				<div class="category-list row">
					<div class="category col-sm-12">
						<span class="collapsable-list">Category 1</span>
		                <ul class="list-panel">
		                    <div>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                    </div>
		                </ul>
					</div>
				</div>
				<div class="category-list row">
					<div class="category col-sm-12">
						<span class="collapsable-list">Category 2</span>
		                <ul class="list-panel">
		                    <div>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                    </div>
		                </ul>
					</div>
				</div>
				<div class="category-list row">
					<div class="category col-sm-12">
						<span class="collapsable-list">Category 3</span>
		                <ul class="list-panel">
		                    <div>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                        <li class="custom-control custom-checkbox">
							      <input type="checkbox" class="custom-control-input" id="customCheck1">
							      <label class="custom-control-label" for="customCheck1">Document 1</label>
		                        </li>
		                    </div>
		                </ul>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</body>
	<?php 
			globalJs(); 
	?>
</html>
