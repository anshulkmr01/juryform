<?php
	class UserLogin extends CI_Controller{
		public function index()
		{
			$this->load->view('user/login');
		}

		public function validate(){

			$this->form_validation->set_rules('username','User Name','trim|required',
											array('required' => '%s is Must'));
			$this->form_validation->set_rules('userpassword','Password','trim|required',
											array('required' => '%s is Must'));

			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

			if($this->form_validation->run())
			{
				$username = $this->input->post('username');
				$userpassword = $this->input->post('userpassword');

				$this->load->model('UserModel');
				$userId = $this->UserModel->isValidate($username,$userpassword);

				if($userId){
					//$this->load->library('session');
					// Setting the user id into user session
					$this->session->set_userdata('userId',$userId);
					return redirect('user/UserLogin/welcome');
				}
				else{
					echo "login failed...";
				}

			}

			else
			{
				$this->load->view('user/login');
			}
		}

		public function welcome()
		{
			$this->load->model('UserModel');
			$queryResult = $this->UserModel->getUserData();

			$this->load->view('user/homepage',['userData'=>$queryResult]);
		}
}
?>