<?php
	class UserSignup extends CI_Controller{
		public function index()
		{
			$this->load->view('user/signup');
		}

		public function validate(){

			$this->form_validation->set_rules('username','User Name','trim|required',
											array('required' => '%s is Must'));
			$this->form_validation->set_rules('useremail','Emaill','trim|required|valid_email',
											array('required' => '%s is Must'));
			$this->form_validation->set_rules('userpassword','Password','trim|required',
											array('required' => '%s is Must'));

			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

			if($this->form_validation->run())
			{
				$username = $this->input->post('username');
				$useremail = $this->input->post('useremail');
				$userpassword = $this->input->post('userpassword');

				$this->load->model('LoginModel');
				if($this->LoginModel->isValidate($username,$userpassword)){
					echo "Done,,,,,,,,";
				}
				else{
					echo "login model issue...";
				}

			}

			else
			{
				$this->load->view('user/signup');
			}
		}
}
?>