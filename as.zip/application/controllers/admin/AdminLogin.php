<?php
	class AdminLogin extends CI_Controller{

public function __construct(){

		parent::__construct();
				$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
		}
		public function index()
		{
			if($this->session->userdata('adminId'))
				return redirect('admin/AdminLogin/welcome');
			$this->load->view('admin/login');
		}

		public function validate(){

			$this->form_validation->set_rules('adminemail','Email','trim|required',
											array('required' => '%s is Required'));
			$this->form_validation->set_rules('adminpassword','Password','trim|required',
											array('required' => '%s is Required'));

			if($this->form_validation->run())
			{
				$adminemail = $this->input->post('adminemail');
				$adminpassword = $this->input->post('adminpassword');

				$this->load->model('AdminModel');
				$adminId = $this->AdminModel->isValidate($adminemail,$adminpassword);

				if($adminId){
					//$this->load->library('session');
					// Setting the user id into user session
					$this->session->set_userdata('adminId',$adminId);

					return redirect('admin/AdminLogin/welcome');
				}
				else{
					$this->session->set_flashdata('login_failed','Invalid Email or Password');
					return redirect('admin/AdminLogin/index');
				}

			}

			else
			{
				$this->load->view('admin/login');
			}
		}

		public function welcome()
		{
			if(!$this->session->userdata('adminId'))
				return redirect('admin/AdminLogin/');

			$this->load->model('AdminModel');
			$queryResult = $this->AdminModel->getCategories();

			$this->load->view('admin/dashboard',['categoriesData'=>$queryResult]);
		}

		public function logout(){
			$this->session->unset_userdata('adminId');
			$this->session->set_flashdata('logout_success',"Logout Successfully");
			return redirect ('admin/AdminLogin/');
		}

		public function createCategory(){
			$this->load->view('admin/createCategory');
		}

		public function categoryValidate(){

			$this->form_validation->set_rules('newCategory','Category','trim|required',
									array(['required'=>'%s is Required']));
			if($this->form_validation->run()):
				$categoryName = $this->input->post('newCategory');

				$this->load->model('AdminModel','newCategory');

				if($this->newCategory->addCategory($categoryName)){
					
					$this->session->set_flashdata('success','Category Created Successfully');
					return redirect('admin/adminLogin/createCategory');

				}
			else{
					$this->session->set_flashdata('error','Category Adding Failed');
					return redirect('admin/adminLogin/createCategory');

			}

			endif;


			$this->load->view('admin/createCategory');
		}

		public function deleteCategory(){

			$categoryId = $this->input->post('categoryId');
			$this->load->model('AdminModel');
			if($this->AdminModel->deleteCategory($categoryId))
			{
					$this->session->set_flashdata('success','Category Created Successfully');
					return redirect('admin/AdminLogin/welcome');

			}
			else{
					$this->session->set_flashdata('error','Category Adding Failed');
					return redirect('admin/AdminLogin/welcome');

			}
		}


		public function editCategory(){
			$categoryName = $this->input->post('categoryName');
			$categoryId = $this->input->post('categoryId');
			$this->load->view('admin/updateCategory',['categoryName'=>$categoryName,'categoryId'=>$categoryId]);
		}

		public function updateCategory(){
			$this->form_validation->set_rules('editCategory','Category Name','trim|required',
											array('required' => '%s is Required'));

			$editCategory = $this->input->post('editCategory');
			$CategoryId = $this->input->post('categoryId');

			if($this->form_validation->run()){
				$this->load->model('AdminModel');
				if($this->AdminModel->updateCategoryName($CategoryId,$editCategory)){

					$this->session->set_flashdata('success','Name Changed Successfully');
					return redirect('admin/AdminLogin/welcome');
				}
				else{
					$this->session->set_flashdata('error','Name Could not Changed');
					return redirect('admin/AdminLogin/welcome');
				}
			}
			else
			{
				$this->load->view('admin/updateCategory',['categoryName'=>$editCategory,'categoryId'=>$CategoryId]);
			}
		}

		public function documents(){
			$categoryData = $this->input->post();
			$this->load->view('admin/documents',['categoryData'=>$categoryData]);
		}
}
?>