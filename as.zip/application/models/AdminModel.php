<?php

	class AdminModel extends CI_Model
	{
		function isValidate($adminemail,$adminpassword)
		{
				$query = $this->db->where(['adminemail'=>$adminemail, 'adminpassword'=>$adminpassword])
									->get('Admins');
				if($query->num_rows())
				{
					return $query->row()->id;
				}
				else
				{
					return false;
				}
		}

		function getCategories(){
			// Getting Value of User Id from session
			$sessionId = $this->session->userdata('adminId');

			$query = $this->db->get('Documentcategories');
			return $query;
		}

		function addCategory($categoryName){
			return $this->db->insert('Documentcategories',['Categoryname'=>$categoryName]);
		}

		function deleteCategory($categoryId){
			return $this->db->delete('Documentcategories',['ID'=>$categoryId]);
		}


		function updateCategoryName($CategoryId,$editCategory){
			return $this->db->where('id',$CategoryId)
						->update('Documentcategories',['Categoryname'=>$editCategory]);
		}
	}
?>