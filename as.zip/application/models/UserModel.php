<?php

	class UserModel extends CI_Model
	{
		function isValidate($username,$userpassword)
		{
				$query = $this->db->where(['username'=>$username, 'userpassword'=>$userpassword])
									->get('users');
				if($query->num_rows())
				{
					return $query->row()->id;
				}
				else
				{
					return false;
				}
		}

		function getUserData(){
			// Getting Value of User Id from session
			$sessionId = $this->session->userdata('userId');

			$query = $this->db->where(['id'=>$sessionId])->get('users');
			return $query->result();
		}
	}
?>