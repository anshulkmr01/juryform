<?php
	$config=[

			'category_update_rules'=>[
									'field'=>'editCategory',
									'label'=>'Category Name',
									'rules'=>'required'
								]
			]
?>